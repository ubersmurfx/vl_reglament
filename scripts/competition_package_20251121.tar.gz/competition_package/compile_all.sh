#!/bin/bash
echo "Компиляция LaTeX документов..."

cd 04_final_docs
for tex_file in *.tex; do
    if [ -f "$tex_file" ]; then
        echo "Компиляция $tex_file..."
        pdflatex -interaction=nonstopmode "$tex_file"
        pdflatex -interaction=nonstopmode "$tex_file"
    fi
done
cd ..

echo "Готово!"
